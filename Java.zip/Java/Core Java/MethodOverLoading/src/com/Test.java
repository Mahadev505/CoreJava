package com;
import java.util.Scanner;
public class Test {

	public static void main(String[] args) {
		
		
		Scanner Scan = new Scanner(System.in);
		System.out.println("Enter The Value of a");
		int a = Scan.nextInt();
		System.out.println("Enter The Value Of B");
		int b = Scan.nextInt();
				
				int Sum = a+b;
				System.out.println("The Sum Of a and  is " +Sum);
				
				
				
				
		

	}

}
