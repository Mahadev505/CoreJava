package com;

public class prog1 {
void add(String x )
{
	}
void add( int y,String x) {
	
}
}
