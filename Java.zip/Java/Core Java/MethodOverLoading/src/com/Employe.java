package com;

import java.util.*;

public class Employe {
	
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("Enter The age");
	int age = s.nextInt();
	System.out.println("Enter Name");
	String Name  = s.next();
	
	System.out.println("Enter Salary");
  double Salary = s.nextDouble();
  
  System.out.println("--------------------");
  
  System.out.println("Age : "+age+"\n Name : "+Name+"\n Salary : "+Salary);
  
	
	
}
}
