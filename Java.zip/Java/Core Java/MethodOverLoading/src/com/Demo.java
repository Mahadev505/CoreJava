package com;

public class Demo {
	public static void main(String[] args) {
		System.out.println("Hello");
		main(10);
		main(12.3);
		
		System.out.println("Bye");
	}
	
	public static int main(int a) {
		System.out.println(a);
		return 12;
		
		
	}
	public static void main(double b) {
		System.out.println(b);
		
	}

}
