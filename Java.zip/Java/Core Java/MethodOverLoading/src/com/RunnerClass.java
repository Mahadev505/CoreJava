package com;

public class RunnerClass {

	public static void main(String[] args) {
			
		MethodOverLoading mol = new MethodOverLoading();
		mol.display(45);
		mol.display(12,"Java");
		mol.display(45.65);
		mol.display();
		
	}

}
