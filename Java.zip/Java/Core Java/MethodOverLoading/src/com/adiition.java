package com;
import java.util.*;


 class adiition {
	
	
	

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter Your Choice");
		String a = s.next();
		
		
		
		if( a=="odd" ) {
			for(int i =2; i<=20;i+=2) {
				System.out.println(i);
			}		
		}
		if( a=="even" ) {
			for(int i =1; i<=10;i+=2) {
				System.out.println(i);
			}	
			
		}
		

		
		
		
	}


}


