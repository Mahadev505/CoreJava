package com;

public class Student 
{
	static int age = 20;
	
	static void study() {
		System.out.println("Student is studying herer");
	}
	public static void main(String[] args) {
		System.out.println("Start");
		System.out.println(Student.age);
		Student.study();
		System.out.println("end");
		System.out.println(age);
		study();
	}
	
}
