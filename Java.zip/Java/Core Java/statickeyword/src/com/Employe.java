package com;

public class Employe {
	static int id = 101;
	
	static void work() {
		System.out.println("Employee is working");
	}
	

}
