package com;

public class Test {
	
	public static void main(String[] args) {
		System.out.println(Employe.id);
		Employe.work();
	}

}
