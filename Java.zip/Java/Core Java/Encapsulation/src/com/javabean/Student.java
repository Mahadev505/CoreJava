package com.javabean;

public class Student {
	
	private int Marks;
	
	public void setMarks(int Marks)
	{
		this.Marks = Marks;
		
	}
	
	public int getMarks()
	{
		return Marks;
	}
	

}
