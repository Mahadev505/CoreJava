package com.javabean;

public class TeatCar {
	
	public static void main(String[] args) {
		Car c = new Car();
		{
			
			
			c.setBrand("Maruthi");
			c.setPrice(1000);
			System.out.println(c.getBrand()+c.getPrice());
		}
	}

}
