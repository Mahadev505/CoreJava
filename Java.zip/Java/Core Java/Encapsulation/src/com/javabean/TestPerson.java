package com.javabean;

public class TestPerson {
	
	
	Person p = new Person();
	public static void main(String[] args) {
		
		Person p = new Person();
		p.setAge(25);
		int age = p.getAge();
		
		System.out.println("Age"+age);
	}

}
