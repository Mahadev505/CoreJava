package com.javabean;

public class TestEmploye {
	
	public static void main(String[] args) {
		Employe e = new Employe();
		e.setName("Krishna");
		e.getName();
		
		System.out.println(e.getName());
	}

}
