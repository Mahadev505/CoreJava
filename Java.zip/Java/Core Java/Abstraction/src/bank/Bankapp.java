package bank;

public class Bankapp {
	
	public static void main(String[] args) {
			Bank b = new ATM();
		
		b.checkbalance();
		
		System.out.println("==========================");
		
		b.deposit(1000);
		b.checkbalance();
		
		
		System.out.println("--------------------");
		b.withdraw(1000);
		b.checkbalance();
		
		System.out.println("=========================");
		b.checkbalance();
		
	}

}
