package bank;

public interface  Bank {
	void withdraw(int amount);
	void deposit(int amount);
	void checkbalance();
	
	

}
