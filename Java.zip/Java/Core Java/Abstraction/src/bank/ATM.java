package bank;

public class ATM  implements Bank{
	
	int balance = 1000;
	
	public void withdraw(int amount) {
		System.out.println("withdrawn"+amount);
		balance -= amount;
		System.out.println("withdraw successfull");
		
	}
	public void deposit(int amount) {
		System.out.println("Deposite amount"+amount);
		balance += amount;
		System.out.println("Deposite Successfull");
	}
	public void checkbalance() {
		System.out.println("Balance is "+balance);
	
	}


}
