package com;

public abstract class Person {
	
	abstract void work();

}
