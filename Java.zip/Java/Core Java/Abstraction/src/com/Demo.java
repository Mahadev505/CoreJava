package com;

import java.util.Scanner;

public class Demo {
	
	public static void main(String[] args) {
		while(true) {
			System.out.println("Enter Choice");
		Scanner scan = new Scanner(System.in);

		
		int choice = scan.nextInt();
		
		switch (choice) {
		case 1:
			
			System.out.println("Hii ding");
			
			break;
			
		case 2:
			System.out.println("Bye Dinga");
			break;
			
		case 3:
			System.exit(0);

		default:
			System.out.println("Invalid Choice");
			break;
		}
		System.out.println("-----------------");
		}
	}

}
