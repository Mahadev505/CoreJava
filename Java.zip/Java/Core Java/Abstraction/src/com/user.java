package com;

public class user {
	
	public static void main(String[] args) {
		Employe e = new Employe();
		e.work();
		
		Person p = new Employe();
		p.work();
	}

}
