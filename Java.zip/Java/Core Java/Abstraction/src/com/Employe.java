package com;

public class Employe extends Person {
	@Override
	
	void work() {
		System.out.println("Working");
		
	}

}
