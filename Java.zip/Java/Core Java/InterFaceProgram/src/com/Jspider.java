package com;

public interface Jspider {
 void Devlop();
 
}
