package com;

public interface HDFC extends ResorveBank {
	
	void withdraw();

}
