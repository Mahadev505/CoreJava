package com;

public interface Vehicle {
	int no =1234;
	
	
	void start();

}
