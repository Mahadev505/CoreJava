package com;

public class Guldu implements Person {
	
	@Override
	public void eat() {
		
		System.out.println("eating Biriyani");
		
	}
	public static void main(String[] args) {
		System.out.println(Person.id);
		
		Guldu g = new Guldu();
		g.eat();
	}
}
