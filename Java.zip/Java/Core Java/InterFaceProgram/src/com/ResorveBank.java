package com;

public interface ResorveBank {
	void Deposit();

}
