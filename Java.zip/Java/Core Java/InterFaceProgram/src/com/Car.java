package com;

public class Car implements Vehicle{
	
	
	public void start() {
		System.out.println("Car Started");
	}
	public static void main(String[] args) {
	Car c = new Car();
	System.out.println(Vehicle.no);
	c.start();
	}

}
