package com;

public interface Qspider {
	
	void test();
	

}
