package com;

public class Employe extends TestYantr  implements Jspider,Qspider {
	@Override
	
 public void Devlop() {
		System.out.println("Devlop The Projwct");
		
	}
	public void test() {
		System.out.println("Trsting");
		
	}
	
	public static void main(String[] args) {
		
	}

}
