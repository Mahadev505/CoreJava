package com;

public class TestYantr {
	void work() {
		 
	}

}
