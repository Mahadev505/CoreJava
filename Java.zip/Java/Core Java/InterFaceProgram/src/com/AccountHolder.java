package com;

public class AccountHolder implements HDFC {
	
	public void withdraw()
	{
		System.out.println("WithDraw");
		
	}
	public void Deposit()
	{
		System.out.println("Deoitse");
		
	}
	
	public static void main(String[] args) {
		AccountHolder acc = new AccountHolder();
		System.out.println();
		acc.Deposit();
		acc.withdraw();
	}

}
