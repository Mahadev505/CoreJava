package com;

public interface Person 
{
	int id = 101;// public static final 101
	void  eat();

}
