package com;

public class Student{
	int age;
	String name;
	
	Student(int age,String name){
		this.age =age;
		this.name= name;
		
	
		
	}
	public static void main(String[] args) {
		Student s1 = new Student(19, "Mahadev");
		Student s2 = new Student(17, "guldu");
		Student s3 = new Student(99, "int");
		
	
		
		Student[] s = new Student[3];
		s[0] = s1;
		s[1] = s2;
		s[2] = s3;
		
		
		for(int i=0;i<s.length;i++) {
			System.out.println(s[1].age+" "+s[1].name);
			
			Student[] p = new Student[3];
			p[0] = s1;
			p[1] = s2;
			p[2] = s3;
			
		}
		
		System.out.println("==============");
		
		
		
		
	}
	

}
