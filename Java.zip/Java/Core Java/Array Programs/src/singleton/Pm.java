package singleton;

public class Pm {
	String name = "modi";
	private static Pm p;
	
	private Pm() {
		System.out.println("pm got elected");
		
	}
	  public static void pmhelper() {
		  if(p == null) {
		   p = new Pm();
		  }
		  
		   
		  
	  }
	
	

}
