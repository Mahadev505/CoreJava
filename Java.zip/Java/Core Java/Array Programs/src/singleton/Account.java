package singleton;

public class Account {
	private static Account obj = null;
	
	private Account()
	{
		System.out.println("Object is created ");
		
	}
	
	public static void createobject() {
		if(obj==null) {
			obj = new Account();
			
		}
		else {
			System.out.println("Cannot create new object");
		}
		
	}
}
