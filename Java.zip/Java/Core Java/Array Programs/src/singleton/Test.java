package singleton;

public class Test {
	public static void main(String[] args) {
		Pm.pmhelper();
		Pm.pmhelper();
	}

}
