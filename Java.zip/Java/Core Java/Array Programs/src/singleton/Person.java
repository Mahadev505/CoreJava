package singleton;

public class Person {
	public static void main(String[] args) {
		AdharCard.createAdharobj();
		AdharCard.createAdharobj();
	}

}
