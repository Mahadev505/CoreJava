package singleton;

public class AdharCard {
	
	private static AdharCard ac;
	
	private AdharCard()
	{
		System.out.println("Object Created ");
		
	}
	
	static void createAdharobj()
	
	{
		
		if (ac ==null) {
			ac = new AdharCard();
			
		}
		else {
			System.out.println("Object Only creates ones");
		}
		
	}	
}
