package com;

public class User extends Car {
	
	void stop() {
		
	}
	void start() {
		System.out.println("Car Started ");
	}
	public static void main(String[] args) {
		User u = new User();
		u.start();
		u.stop();
		u.shiftgears();
	}
	
	

}
