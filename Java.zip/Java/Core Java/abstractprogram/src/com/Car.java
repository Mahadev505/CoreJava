package com;

public abstract class Car extends Vehicle {
	
	 abstract void stop() ;
	 
	

}
