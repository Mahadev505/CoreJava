package com;

public abstract class Person {
	 void eat() {
		
	}
	 
	abstract  void work();
	
}
