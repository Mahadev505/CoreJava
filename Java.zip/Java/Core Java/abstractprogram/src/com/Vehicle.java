package com;

public   abstract class Vehicle {
	
	abstract void start();
	void shiftgears()
	{
		System.out.println("Shifting gears here");
		
	}
	

}
