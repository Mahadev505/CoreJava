package runtime;

public class Employe {

}
