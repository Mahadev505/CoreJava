package runtime;

public class Car extends Vehicle {
	
	void start()
	{
		
		System.out.println("car started");
	}

}
