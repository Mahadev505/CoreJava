package runtime;

public class Solution {
	public static void main(String[] args) {
		
	
	
	Vehicle v = new Car();
	v.start();
	
    Vehicle v2 = new Bike();
    v2.start();
    		
	
	
	
	}
	
	

}
