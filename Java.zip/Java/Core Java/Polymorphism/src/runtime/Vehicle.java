package runtime;

public class Vehicle {
	
	void start() {
		
		System.out.println("Vehicle Started");
	}
	
	

	
}
