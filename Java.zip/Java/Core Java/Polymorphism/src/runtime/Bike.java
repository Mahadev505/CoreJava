package runtime;

public class Bike extends Vehicle {
	
	void start()
	{
		System.out.println("Bike Started");
	}
	

}
