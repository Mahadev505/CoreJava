package compiletime;

public class Myntra {
	
   void	Purchase(String ProductName)
	{
	   System.out.println(ProductName);
	   
	}
   
   
   void Purchase(String ProductName, int cost)
   {
	   System.out.println(ProductName + " "+cost);
	   
   }
   
   void Purchase( int productid)
   {
	   System.out.println(productid);
	   
   }
   
   void Purchase(int cost,String ProductName )
   {
	   
   }

}
