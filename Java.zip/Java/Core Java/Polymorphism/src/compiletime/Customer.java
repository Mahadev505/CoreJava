package compiletime;

public class Customer {
	
	public static void main(String[] args) {
		
		Myntra m = new Myntra();
		m.Purchase(101);
		m.Purchase(1000,"Mobile");
		m.Purchase("laptop");
		
	}

}
