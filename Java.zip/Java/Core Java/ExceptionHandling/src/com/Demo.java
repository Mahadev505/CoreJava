package com;

import java.util.Scanner;

public class Demo {
  public static void main(String[] args) {
	System.out.println("Start");
	
	Scanner Scan = new Scanner(System.in);
	System.out.println("Enter The Value of a");
	
	int a = Scan.nextInt();

	
	System.out.println("Enter The Value Of b");
	int b  = Scan.nextInt();
	try{
		System.out.println("a/b :"+a/b);
		
	}
	catch (ArithmeticException c) {
		System.out.println("donot devide by");
		
		// TODO: handle exception
	}
	
	
	
	
	
	Scan.close();
	
	
	System.out.println("End");
}
	
}
