package com;

public class Test {
	public static void main(String[] args) {
		int [] a ={12,23,34,};
		try {
		System.out.println(a[99]);
		}
		catch (ArrayIndexOutOfBoundsException ab) {
			System.out.println("Enter valid array");
			
			// TODO: handle exception
		}
		
	}

}
