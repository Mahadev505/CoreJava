package com;

public class car {
	static {
		System.out.println(1);
	}
	public static void main(String[] args) {
		System.out.println("2");
		
		car c = new car(); 
		
		
		
	}
	{
		System.out.println("3");
	}

}
