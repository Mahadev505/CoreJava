package com;

public class Package {
	static {
		age = 10;
		System.out.println("initializing age to 10");
	}
	static int age;
	public static void main(String[] args) {
		System.out.println(Package.age);
	}
	static {
		age = 20;
		System.out.println("initializing age into 20");
	}

}
