package com;

public class Employe {
	{
		
		System.out.println("initilizing id to 10");
		id =10;
	}
	
	int id;
	
	public static void main(String[] args) {
		Employe e = new Employe();
		System.out.println(e.id);
	}
{
		
		System.out.println("initilizing id to 10");
		id =20;
	}
}

