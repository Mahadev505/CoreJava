package com;

public class test {
	
	{
		System.out.println("non static Block 1 ");
	}
	
	public static void main(String[] args) {
		System.out.println("Start");
		
		test t = new test();
		
		System.out.println("End");
	}

}
