package com;

public class Test1 {
	
	int display() {
		return 10;
	}
	public static void main(String[] args) {
		System.out.println("Start");
		Test1 t = new Test1();
		int result = t.display();
		System.out.println(result);
		
		System.out.println("End");
		
	}

}
