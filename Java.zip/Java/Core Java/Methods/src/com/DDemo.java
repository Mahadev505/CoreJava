package com;

public class DDemo {
	 static void display(int num1,int num2) {
		int sum = num1+num2;
		System.out.println(sum);
	}
	public static void main(String[] args) {
//		DDemo d1 = new DDemo();
	display(12,13);
		}

}
