package com;

public class Solution {
	void m1(){
		System.out.println("Learning Methods ");
		
	}
	
	void m2(String Name,int age){
		System.out.println(Name+" "+age);
		
	}
	
	String m3(){
		return "Jspide"; 
		
	}
	
	int m4(int a, int b){
		return a+b;
		
	}
	
	

}
