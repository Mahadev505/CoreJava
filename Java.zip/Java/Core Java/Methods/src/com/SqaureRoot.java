package com;

public class SqaureRoot {
	int square (int a,int b){
		int sum = a+b; 
		return sum;
		
	}
	public static void main(String[] args) {
		SqaureRoot  s = new SqaureRoot();
		
		System.out.println(s.square(12, 12));
	}

}
