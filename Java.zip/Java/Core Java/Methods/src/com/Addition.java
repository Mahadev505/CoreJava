package com;

class Addition {
	void add(int a, int b) {
		int sum = a+b;
		int sub = a-b;
		int mul =a*b;
		System.out.println(sum);
		System.out.println(sub);
		System.out.println(mul);
		
	}
	public static void main(String[] args) {
		Addition add = new Addition();
		add.add(20 ,12);
		
	}
}
