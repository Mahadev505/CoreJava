package com;

public class MainClass {
	public static void main(String[] args) {

		Solution s = new Solution();
		s.m1();
		
		
		System.out.println("********");
		s.m2("Mahadev",22);
		
		
		
		String Company = s.m3();
		System.out.println(Company);
		
		
		int result = s.m4(12,23);
		System.out.println(result);



	}

}
