package com;

public class Solutiona {
	int m1(int n) {
		return n*n;
		
		
	}
	String m2(String Name,String age){
		return Name+age;
		
	}

}
