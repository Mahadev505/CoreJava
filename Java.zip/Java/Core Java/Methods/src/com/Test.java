package com;

public class Test {
 int display(int a, int b) { 
	 int sum = a+b;
	 System.out.println(sum);
	 
	 return 12;
 }
 public static void main(String[] args) {
	Test t = new Test();
	int result = t.display(12, 23);
	System.out.println(result);
	
}
 
}
