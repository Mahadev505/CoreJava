package com;

public class Prog {
	
	void add(int a, int b) {
		int sum = a+b;
		
		System.out.println("sum of "+a+"&"+b+"is"+sum);
	}
	
	
	public static void main(String[] args) {
		Prog p = new Prog();
			p.add(12,34);
			p.add(39, 55);
	}
	

}
