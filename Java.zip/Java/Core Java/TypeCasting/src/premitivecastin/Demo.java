package premitivecastin;

public class Demo {
	public static void main(String[] args) {
		
		System.out.println("=======widening=======");
		int a = 10;
		double b =  a;
		System.out.println(a+"  "+b);
		
		char c = 'A';
		int D = c;
		
		
		System.out.println(c+" "+D);
		
		System.out.println("=======Narrowing========");
		double x = 3.45;
		
		int y = (int)x; 
		System.out.println(y+" "+x);
		
		
		int  p = 66;
		
		char q = (char)(p);
		
		System.out.println(p+" "+q);
		
		
		int i = 99;
		char j = (char)i;
		
		System.out.println(i+" "+j);
		
		
		System.out.println("============================");
		
		System.out.println("A"+"B");
		System.out.println("A"+20);
		System.out.println('A'+'B');
		System.out.println('a'+20);
		
		
		System.out.println('a'+"b");
		
		
		
	}

}
