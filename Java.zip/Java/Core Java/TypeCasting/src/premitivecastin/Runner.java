package premitivecastin;

public class Runner {
	public static void main(String[] args) {
		System.out.println(10);
		System.out.println(10.5f);
		
		
		float a = 3.5f;
		
		System.out.println("=============");
		
		long mobileno = 99999999999l;
		
		System.out.println(mobileno);
	}

}
