package nonpremitivecasting;

public class Son extends Father{
	
//	Uppcasting
	
	
	String name = "Mahadev";
	
	

}
