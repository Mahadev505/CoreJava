package nonpremitivecasting;

public class Vehicle {
	
	String Brand = "Bmw";
	
	void Start()
	{
		System.out.println("Vehicle Started");
	}
	

}
