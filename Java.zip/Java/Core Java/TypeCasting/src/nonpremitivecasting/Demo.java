package nonpremitivecasting;

public class Demo {
	
public static void main(String[] args) {
	Vehicle v  = new Car();
	
	v.Start();
	
	
	System.out.println("========================");
	
	Car c = (Car)v;
	c.Start();
	c.Stop();
}

}
