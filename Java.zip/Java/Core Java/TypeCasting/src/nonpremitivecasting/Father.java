package nonpremitivecasting;

public class Father 
{
	int age =45;

}
