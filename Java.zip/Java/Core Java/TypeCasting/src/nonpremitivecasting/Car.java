package nonpremitivecasting;

public class Car extends Vehicle {
	
	
	String Fuel = "Petrol";
	
	void Stop ()
	{
		System.out.println("Car Stopeed");
	}

}
