package nonpremitivecasting;

public class Test {
public static void main(String[] args) {
		//Up casting
		Father f = new Son();
		
		
		//Down Casting
		Son s = (Son)f;
		
		System.out.println(s.age+" "+s.name);
		
		  
	}


}
