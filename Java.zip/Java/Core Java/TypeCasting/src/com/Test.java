package com;

public class Test {
	
	public static void main(String[] args) {
		Son s =new Son();
		Doughter d = new Doughter();
		
		
		System.out.println(s instanceof Son);
		System.out.println(s instanceof Father );
		System.out.println(d instanceof Doughter);
		System.out.println(d instanceof Father);
		
		
		
		if(s instanceof Father)
		{
			System.out.println("Down Cast to Son");
		}
		else 
		{
			System.out.println("Down Cast to Doughter");
			
		}
	}

}
