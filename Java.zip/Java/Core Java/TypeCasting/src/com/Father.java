package com;

public class Father 
{
	int x =30;
	
	

}
