package com;

import java.util.Scanner;

public class User {
	public static void main(String[] args) {
		
		Shop sh = new Shop();
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter Your Choice\n 1.Mobile\n 2.Lapatop");
		int choice = s.nextInt();
		
		Electronics obj=sh.sales(choice);
		
		if(obj instanceof Mobile) {
			System.out.println("Buying Mobile");
		}
		
		else if(obj instanceof Laptop)
		{
			System.out.println("Buying Laptop");
		}
		
		else
		{
			
			System.out.println("Enter Valid Choice");
		}
		
		
		
		
	}
	
	

}
