package com;

public class Laptop extends Electronics{
	
	String color = "Grey";

}
