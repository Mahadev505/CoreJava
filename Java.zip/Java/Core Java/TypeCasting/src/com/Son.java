package com;

public class Son extends Father {

}
