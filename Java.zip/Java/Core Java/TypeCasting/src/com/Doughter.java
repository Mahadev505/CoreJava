package com;

public class Doughter extends Father {

}
