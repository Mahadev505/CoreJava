package com;

public class Mobile  extends Electronics{
	
	int price = 400;
	

}
