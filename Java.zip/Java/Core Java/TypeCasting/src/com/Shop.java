package com;

public class Shop {
	
	Electronics sales(int choice) {
		if (choice == 1) {
			Mobile m = new Mobile();
			return m; 
		}
		
		else if(choice == 2)
		{
			Laptop l = new Laptop();
			return l;
		}
		else {
			return null;
		}
	}

}
