package org;
import com.Employee;

public class Testemploye {
	
	public static void main(String[] args) {
		Employee e = new Employee();
		
		e.work();
	}

}
