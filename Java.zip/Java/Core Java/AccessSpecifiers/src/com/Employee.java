package com;

public class Employee {
	
	public void work() {
		System.out.println("Employe is working");
	}

}
