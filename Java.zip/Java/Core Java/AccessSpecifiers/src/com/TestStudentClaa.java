package com;

public class TestStudentClaa {
	
	public static void main(String[] args) {
		Student s = new Student();
		System.out.println(s.marks);
		
		s.study();
	}
	
	

}
