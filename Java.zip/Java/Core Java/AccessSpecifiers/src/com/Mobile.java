package com;

public class Mobile {
	
	 private void chat()
	{
		 System.out.println("Some secrete information");
		 
		
	}
	 public static void main(String[] args) {
		Mobile m = new Mobile();
		m.chat();
	}

}
