package com;

public class Laptop {
	
	int cost = 4500;
	
	
	void devlop(){
		
		System.out.println("Devoloping");
		
	}
	
	public static void main(String[] args) {
		Laptop l = new Laptop();
		System.out.println(l.cost);
		l.devlop();
		
		
	}

}
