package com;

public class person {
	public int age = 25;
	
	public person()
	{
		System.out.println("In person Constructor");
	}
	
	public  void walk()
	{
		System.out.println("Person is walking");
		
	}
	
	public static void main(String[] args) {
		person p = new person();
		p.walk();
		
		System.out.println(p.age);
	}

}
