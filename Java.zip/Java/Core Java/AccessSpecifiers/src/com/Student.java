package com;

public class Student {
	public int marks =34 ;
	
	
	public Student()
	{
		System.out.println("Hello");
		
	}
	
	public void study() {
		System.out.println("fed up of stidying");
		
	}
	

}
