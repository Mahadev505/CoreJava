package com;

public class Check {
	void check(int a) {
		
		if(a>0) {
			System.out.println("Positive");
		}
		 else if (a<0) {
			 System.out.println("The Give Numbr is Negative");
		 }
		
		 else {
			 System.out.println("it is Zero");
		 }
	}

}

