package com;

public class adds {
	void adds(int a,int b) {
		int sum = a+b;
		System.out.println(sum);
	}

}
