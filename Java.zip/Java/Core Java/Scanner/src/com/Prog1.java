package com;
import java.util.Scanner;


public class Prog1 {
	public static void main(String[] args) {
		System.out.println("Start");
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter The Value of a ");
		int a = scan.nextInt();
		System.out.println("Enter The Value Of B");
		int B =scan.nextInt();
		int c = scan.nextInt();
		int sum  = a+B+c;
		System.out.println(sum);
		
		
		System.out.println("End");
		scan.close();
	}
	

}
