package com;
import java.util.Scanner;

public class Employe {

	private static Scanner s;

	public static void main(String[] args) {
		s = new Scanner(System.in);
		
		System.out.println("Enter Age");
		int age = s.nextInt();
		System.out.println("Enter Name");
		String Name = s.next();
		System.out.println("Enter Your Salary");
		double salary = s.nextDouble();
		
		
		
		System.out.println("Name Is "+Name);
		System.out.println("age is"+age);		
		System.out.println("salary is"+salary);
		
		

	}

}
