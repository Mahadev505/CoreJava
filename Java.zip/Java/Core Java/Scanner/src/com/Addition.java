package com;

public class Addition {
	void Adition(int a,int b) {
		int sum = a+b;
		System.out.println(sum);
	}

}
