package com;
import java.util.Scanner;

public class Solution {

	public static void main(String[] args) {
		Check c = new Check();
		try (Scanner s = new Scanner(System.in)) {
			for(int i =0;i<=5;i++) {
			
			System.out.println("Enter Your Number");
			int a = s.nextInt();
			c.check(a);
			
			
			

}
		}
	}

}
