package com;

import java.util.Scanner;

public class Prac1 {
	
	void sum(int a, int b) {
		int sum = a+b;
		System.out.println("The Sum is"+sum);
		
		
		
	}
	
	public static void main(String[] args) {
		Prac1  p = new Prac1();		
		Scanner s = new Scanner(System.in);
		
		
		System.out.println("Enter The Value 1");
		int a = s.nextInt();
		System.out.println("Enter The Value 1");
		int b = s.nextInt();
		
		p.sum(a, b);
		
		
		
		
		
	}

}
