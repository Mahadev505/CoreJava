package com;

import java.util.Arrays;

public class MultidimensionalArray {
	public static void main(String[] args) {
		int [] []  numberes = {{1,2,3,4},{9,3,4,6,6}};
		
		
		System.out.println(Arrays.deepToString(numberes));
	}

}
