package com;
import java.util.Scanner;
import java.util.InputMismatchException;

public class ScannerClass {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Enter your age: ");
            if (sc.hasNextInt()) {
                int age = sc.nextInt();
                if (age >= 18) {
                    System.out.println("You are eligible to vote");
                } else if (age < 0) {
                    System.out.println("Age cannot be negative. Please enter a valid age.");
                } else {
                    System.out.println("You are not eligible to vote");
                }
            } else {
                System.out.println("Invalid input. Please enter an integer.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter an integer.");
        }
    }
}

