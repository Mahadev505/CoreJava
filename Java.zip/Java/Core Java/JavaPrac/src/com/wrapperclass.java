package com;

public class wrapperclass {
	public static void main(String[] args) {
	String a  ="1.1";
	
	double b = Double.parseDouble(a)+2;
	System.out.println(b);
	

	}
}


