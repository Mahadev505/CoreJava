package com;

import java.text.NumberFormat;


public class NumberFormatsss {
	public static void main(String[] args) {
		 NumberFormat.getPercentInstance();
		 
		
		
		
		
		
	}

}
