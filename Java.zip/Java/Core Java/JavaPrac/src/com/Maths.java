package com;
import java.*;
import java.lang.*;;

public class Maths {
	
	public static void main(String[] args) {
		Double a = Math.random();
		
		a = a*100;
		System.out.println(Math.ceil(a));
	}

}
