package com;

public class PRAC {
	public static void main(String[] args) {
		
		String message = " \"Hello\" world  ";
		message.trim();
		System.out.println(message.replace("w", "W"));
		
	}

}
