package com;

import java.util.Scanner;

public class PercentageCalculator {
	
	public static void main(String[] args) {
		
		final byte PERCENT= 100;
		
		final byte SUBJECTS = 4;
		
	Scanner sc = new Scanner(System.in);
	
	
	
	System.out.println("Enter The Subject1 Marks");
	byte Subject1 = sc.nextByte();
	
	System.out.println("Enter The Subject1 Marks");
	byte Subject2 = sc.nextByte();
	
	System.out.println("Enter The Subject1 Marks");
	byte Subject3 = sc.nextByte();
	
	System.out.println("Enter The Subject1 Marks");
	byte Subject4 = sc.nextByte();
	
	
	
	int total = Subject1+Subject2+Subject3+Subject4;
	System.out.println("Total Marks "+total);
	
	double  percent = (total)/SUBJECTS;
	
	System.out.println("Percentage is"+percent+"%");
	
	
	
	
	
	
	
	
	
	
	
	
		
		
		
	}

}
