package org;

public class Employe {
	
	int id;
	String Name;
	double Salary;
	
	
	Employe(int id,String Name,double Salary)
	{
		this.id = id;
		this.Name= Name;
		this.Salary = Salary;
		
	}
	
	void display()
	{
		System.out.println(this.id);
		System.out.println(this.Name);
		System.out.println(this.Salary);
	}
	
	public static void main(String[] args) {
		Employe e1 = new Employe(101, "dinga", 10.34);
		Employe e2 = new Employe(102, "gundu", 10.01);
		
		
		System.out.println("Employe Details");
		
//		System.out.println("=================");
//		System.out.println("Employe Name : "+e1.Name);
//		System.out.println("Employe id :"+e1.id);
//		System.out.println("Employe salary "+e1.Salary);
		
		e1.display();
		
		System.out.println("========================");
		
//		System.out.println("Employe2 Name"+e2.Name);
//		System.out.println("Employe2 id "+e2.id);
//		System.out.println("Employe salary"+e2.Salary);
		
		e2.display();
		
		
	}
	

}
