package org;

public class Student {
	
	int id;
	String Name;
	int age;
	
	Student(int id,String Name,int age){
		this.id = id;
		this.age = age;
		this.Name = Name;
		
		
		
	}
	
	void display() {
		
		System.out.println("Student id is :"+id);
		System.out.println("Student Name is :"+Name);
		System.out.println("Student age is : "+age);
		
	}
	
	public static void main(String[] args) {
		Student s1 = new Student(12, "Mahadev", 22);
		Student s2 = new Student(12, "Veeresh", 22);
		Student s3 = new Student(12, "Rajesh", 22);
		
		
		s1.display();
		s2.display();
		s3.display();
		
		
	}

	
}
