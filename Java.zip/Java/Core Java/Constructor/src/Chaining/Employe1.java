package Chaining;

public class Employe1 {
	
	public Employe1(int a) {
		System.out.println( a);
	}

}
