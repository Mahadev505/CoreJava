package Chaining;

public class Student {
	
	Student(int id )

	{
		System.out.println("id is:" +id);
	}
	
	Student(String Name)
	{
		this(12);
		System.out.println("Name is"+Name);
		
	}
	
	Student(double Height)
	{
		this("Tom");
	System.out.println("Height is :"+Height);	
	}
	
	
	public static void main(String[] args) {
		Student s = new Student(5.5);
	}

}
