package Chaining;

public class Test extends Employe1 {
	
	public Test(int a) {
		super(a);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		Test t = new Test(12);
		
		
	}

}
