package Chaining;

public class Employe2 {
	
	public Employe2() {
		System.out.println(2);
	}

}
