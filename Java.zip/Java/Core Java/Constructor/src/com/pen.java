package com;

public class pen {
	
	public static void main(String[] args) {
		pen p = new pen();
		
	}

}
