package com;

public class kangaroo {
	
	double height = 5.5;
	
	
	void display()
	{
		double height = 4.4;
		System.out.println(height);
		System.out.println(this.height);
	}
	
	public static void main(String[] args) {
		kangaroo k = new kangaroo();
		k.display();
	}
	

}
