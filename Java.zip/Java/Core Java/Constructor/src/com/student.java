package com;

 class student {
	 
	 int age;
	 student(int a){
		 age = a;
		 
		 
	 }
	 public static void main(String[] args) {
		student s1 = new student(12);
		student s2 = new student(44);
		
		System.out.println(s1.age+" "+s2.age);;
	}

}
