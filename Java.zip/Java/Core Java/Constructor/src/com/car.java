package com;

public class car {
	// non parameterized custom constructor
	car()
	{
		System.out.println("Hello");
	}
	
	public static void main(String[] args) {
		
		System.out.println("Start");
		car c = new car();
		System.out.println("End");
		
	}

}
