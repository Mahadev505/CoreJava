package com;

public class person {
	int age;
	String Name;
	
	person(int age,String Name){
		this.age = age;
		this.Name = Name;
		
	}
	
	public static void main(String[] args) {
		person p1 = new person(21, "Mhade");
		person p2 = new person(22,"bama");
		
		System.out.println(p1.age+""+p1.Name+""+p2.age+" "+p2.age);
	}

}
