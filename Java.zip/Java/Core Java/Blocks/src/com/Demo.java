package com;

public class Demo {
	static
	{
		System.out.println("In static block1");
	}
	
	static {
		System.out.println("In static block2");
	}
	public static void main(String[] args) {
		System.out.println("Hello");
		
	}

}
