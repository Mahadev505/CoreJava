package com;

public class Test {
	{
		System.out.println("In non static block 1");
	}
	public static void main(String[] args) {
		Test t = new Test();
		System.out.println("Start");
		
		
		System.out.println("End");
	}
	{
		System.out.println("In non static block 2");
		{
			System.out.println("In non static block 3");
		}
		
	}

}
