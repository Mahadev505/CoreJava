package com;

public class Student {
	 static int age;
	 static {
		 age = 10;
		 System.out.println(age);
		
	 }
	 
	 public static void main(String[] args) {
		System.out.println(age);
	}
	 static 
	 {
		 age = 20;
		 System.out.println(age);
	 }
	 
	

}
