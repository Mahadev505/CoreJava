package com;

import java.util.Scanner;

public class Caclculator {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter The no1");
		int no1 = sc.nextInt();
		
		System.out.print("Enter The no2");
		int no2 = sc.nextInt();
		
		System.out.print("enter the operator");
		char operator = sc.next().charAt(0);
		
		int res = caluclate(no1,no2,operator);
	}

}
