package com;

public class Whileloop {
	
	public static void main(String[] args) {
		int i =0;
		while(i<12) {
			System.out.println("Helloe world");
			i++;
		}
	}

}
