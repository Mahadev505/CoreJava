package com;

import java.util.Scanner;
public class AddTwoNumber {
	int add(String operator ,int a, int b) {
		if (operator =="+") {
			return a+b;
			
		}
//		
//		else if(operator == "Sub") {
//			System.out.println( a-b);
//		}
//		
//		else if (operator == "mult") {
//			System.out.println(a*b);
//		}
//		else if(operator == "div") {
//			System.out.println(a/b);
//	
//		}
		return b;
		
	}
	public static void main(String[] args) {
		AddTwoNumber at = new AddTwoNumber();
		for(int i=1;i<=12;i++) {
		Scanner s = new Scanner(System.in);
		System.out.println("Add Opertor");
		String operator = s.next();
		System.out.println("Enter The Value od a");
		int a = s.nextInt();
		System.out.println("Enter The Value of b");
		int b = s.nextInt();
		
		at.add(operator,a,b);
		}
		
	}
	

}

