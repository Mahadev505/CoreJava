package com;

import java.util.Scanner;

public class loops {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int input = sc.nextInt();
		System.out.println("Enter Your Input");
		
		if (input >1 & input<100 ) {
		
		
		
		
		
		
		
		for(int i=0;i<100;i++) {
			
			System.out.println("Hare Krishna");
			
		}
	}
	
	else {
		System.out.println("invalid input");
		
	}

}}
