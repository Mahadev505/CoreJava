package com;

public class SwapingTwoNumbers {
	public static void main(String[] args) {
		int a= 10;
		int b =20;
	
		System.out.println("a is :"+a+"b is :"+b);
		int t = a;
		a =b;
		b=t;
		
		System.out.println("after Swapin"+a+" "+b);
		
	}

}
