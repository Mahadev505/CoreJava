package com;

import java.util.Scanner;

public class TableofNumbers {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter your input");
		
		int n = sc.nextInt();
		int sum = 0;
		
		
		for(int i =0;i<11;i++) {
			
			sum = i*n;
			
			System.out.println(sum);
			
			
			
		}
		
	}

}
