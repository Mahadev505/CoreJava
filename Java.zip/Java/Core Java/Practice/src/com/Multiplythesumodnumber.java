package com;

import java.util.Scanner;

public class Multiplythesumodnumber {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter your number");
		
		int n = sc.nextInt();
		
		int sum = 0;
		
		for(int i=0;i<=n;i++) {
			sum = n*i;
			System.out.println(sum);
			
		}
		System.out.println("The total sum is"+sum);
		
		
	}

}
