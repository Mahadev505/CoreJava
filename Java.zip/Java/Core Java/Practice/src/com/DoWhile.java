package com;

public class DoWhile {
	
	public static void main(String[] args) {
		
		int i =13;
		do {
			System.out.println(i);
			i ++;	
		}while(i<12); 
	}

}
