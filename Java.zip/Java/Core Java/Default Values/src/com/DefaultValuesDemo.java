package com;

 class DefaultValuesDemo 
{
	 int a;
	 double b;
	 char c;
	 String e;
	 boolean d;
	 
	 public static void main(String[] args) {
		DefaultValuesDemo dvd = new DefaultValuesDemo();
		System.out.println(dvd.a);
		System.out.println(dvd.b);
		System.out.println(dvd.c);
		System.out.println(dvd.d);
		System.out.println(dvd.e);
		
	}

}
