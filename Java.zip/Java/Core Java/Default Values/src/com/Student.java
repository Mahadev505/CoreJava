package com;

 class Student {
	 int Marks;
	 String Name;
	 
	 
	 public static void main(String[] args) {
		 
		 Student s1  = new Student();
		 Student s2 = new Student();
		 
		 s1.Name = "Mahadev ";
		 s1.Marks  = 28;
		 s2.Name = "Krishna";
		 s2.Marks = 100;
		 
		 
		 System.out.println(s1.Marks+" "+s1.Name);
		 System.out.println(s2.Marks+" "+s2.Name);
			
		}
	 
	 
	

}

