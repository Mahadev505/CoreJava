package com;

public class Employe {
	public static void main(String[] args) {
		Employe1 Emp1 = new Employe1();
		Employe1 Emp2 = new Employe1();
		Employe1 Emp3 = new Employe1();
		Emp1.Name =  "Krishna";
		Emp1.age = "18";
		Emp1.Salary = 100000;
		
		Emp2.Name =  "Shiva";
		Emp2.age = "08";
		Emp2.Salary = 1000000;
		
		
		Emp3.Name =  "VeeraBhadreshwar";
		Emp3.age = "06";
		Emp3.Salary = 10000000;
		
		
		System.out.println(Emp1.Name+" "+Emp1.age+" "+Emp1.Salary);
		System.out.println(Emp2.Name+" "+Emp2.age+" "+Emp2.Salary);
		System.out.println(Emp3.Name+" "+Emp3.age+" "+Emp3.Salary);
		
		
	}

}
