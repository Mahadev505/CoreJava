package com;

 class Employe1 {
	 String Name ;
	 String age;
	 int Salary;

}
