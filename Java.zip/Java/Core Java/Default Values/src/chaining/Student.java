package chaining;

public class Student {
	
	Student(int age)
	{
		this("tom");
		System.out.println("Student age is "+age);
	}
	Student(String Name)
	{
	
		System.out.println("Student  Name is "+Name);
		
	}
	Student(double Height)
	{
		this(22);
		
		System.out.println("Student Height is"+Height);
	}
	
	public static void main(String[] args) {
		
		
			Student s = new Student(5.8);
	}

}
