package Class;

public class multipleobjects {
	
	int ocst;
	
	public static void main(String[] args) {
		multipleobjects ml = new multipleobjects();
		multipleobjects mo = new multipleobjects();
		
		ml.ocst = 55;
		mo.ocst =99;
		ml.ocst = 10;
		mo.ocst =10;
		int sum = ml.ocst+mo.ocst;
		System.out.println(sum);
		
	}

}
