package Class;

public class Test {

	public static void main(String[] args) {
	Employe emp = new Employe();
	System.out.println(emp.id+" "+emp.Name+"  "+ emp.Salary);
	 }

}
