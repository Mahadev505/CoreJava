package Class;

public class DefaultValues {
	
	static int a;
	static double b;
	static char c;
	static boolean d;
	static String s;
	
	public static void main(String[] args) {
		DefaultValues def = new DefaultValues();
		System.out.println(def.a+" "+def.b+" "+def.c+" "+def.d+" "+def.s);
	}

}
