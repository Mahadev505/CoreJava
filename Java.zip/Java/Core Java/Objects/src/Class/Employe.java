package Class;

public class Employe {
	
	int id= 101;
	String Name = "dom";
	int Salary = 123;
			
			

	

}
