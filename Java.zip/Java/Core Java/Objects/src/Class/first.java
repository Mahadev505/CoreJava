package Class;

public class first {
	
	int age = 20;
	String Name = "Mahadev";
	
	
	public static void main(String[] args) {
		first f = new first();
		System.out.println(f.age+" "+f.Name);
	}

}
