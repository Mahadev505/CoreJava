package Class;

public class program {
		String age;
	public static void main(String[] args) {
		program p = new program();
		System.out.println(p.age);
		

	}

}
