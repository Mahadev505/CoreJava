package Class;

public class DetailsOfStudent {
	String Name;
	int age;
	int rollno;
	public static void main(String[] args) {
		DetailsOfStudent d1 = new DetailsOfStudent();
		DetailsOfStudent d2 = new DetailsOfStudent();
		d1.Name = "Mahadev";
		d1.age= 22;
		d1.rollno = 44;
		System.out.println(d1.age+d1.Name+d1.rollno);
		
	}

}
