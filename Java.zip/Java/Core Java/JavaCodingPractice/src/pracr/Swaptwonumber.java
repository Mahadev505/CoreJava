package pracr;

public class Swaptwonumber {


	
	
	public static void main(String[] args) {
		
		int a =10;
		int b =20;
		System.out.println("Before Swaping"+" "+a+" " +"after swaping"+b);
		
		int t =0;
		t =a;
		a=b;
		b=t;
		
		System.out.println(a+" "+ b);
	}
	
}
