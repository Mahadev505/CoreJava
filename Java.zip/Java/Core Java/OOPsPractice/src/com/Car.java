package com;

public class Car {
	
	String color ;
	String type;
	
	public void Move() {
		System.out.println("Car Moving");
	}
	

}


