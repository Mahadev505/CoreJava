package com;

public class OOPS {
	public static void main(String[] args) {
		Car car11 = new Car();
		
		car11.Move();
		
		
	}

}
