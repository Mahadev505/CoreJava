package com;

public class Whatsapp3 extends Whatsapp2 {
	void Display()
	{
		super.Display();
		
		System.out.println("video Call Supported");
	}
	
	void call()
	{
		super.call();
		System.out.println("Video call supported");
	}
	void Story()
	{
		System.out.println("Upload images supported");
	}
	public static void main(String[] args) {
		Whatsapp3 w3 = new Whatsapp3();
		w3.Display();
		w3.call();
	}

}
