package com;

public class vehicle {
	void start()

		{
		System.out.println("Vehicle Started");
		
		}
	void stop()
	{
		System.out.println("Vehicle Stopped");
	}
	
	
	}
