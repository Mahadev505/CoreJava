package com;

public class Father 
{
	void Bike()

	{
		System.out.println("old Fashioned Fathers Bike");
	}
}
