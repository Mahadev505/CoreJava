package com;

 class Son extends Father{
	 @Override
	 void Bike()
	 {
		 System.out.println("New Sons Bike");
		 
	 }
	 
	 public static void main(String[] args) {
		Son s = new Son();
		s.Bike();
	}

}
