package com;

public class Car extends vehicle {
	@Override
	void start()
	{
		super.start();
		System.out.println("Car Started");
	}
	
	void ShiftGears()

	{
		
		System.out.println("Gear Shifted");
	}
	
	public static void main(String[] args) {
		Car c = new Car();
		c.start();
	}
}
