package com;

public class Insta1 {

}
