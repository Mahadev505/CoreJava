package com;

public class Whatsapp1 {
	
	void Display()
	{
		System.out.println("SingleTick Supported");
	}

}
