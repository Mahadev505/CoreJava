package com;

public class Whatsapp2 extends Whatsapp1 {
	@Override
	void Display()
	{
		super.Display();
		System.out.println("Doubletick Supported");
	}
	
	void call()
	{
		System.out.println("Calling feauture Supported");
	}

}
