package com;

public class Test {
	public static void main(String[] args) {
		
		Son s = new Son();
		
		
		System.out.println(s.age+" "+s.name);
		
	}

}
