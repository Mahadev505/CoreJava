package com;

public class Son extends father {
	
	String name = "tom";

}
