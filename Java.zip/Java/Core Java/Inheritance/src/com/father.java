package com;

public class father {
	
	int age = 40;
	

}


