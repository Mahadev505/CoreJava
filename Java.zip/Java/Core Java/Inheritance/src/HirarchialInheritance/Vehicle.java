package HirarchialInheritance;

public class Vehicle {
	
	String Brand = "BMW";
	

}
