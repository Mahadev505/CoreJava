package HirarchialInheritance;

public class Car extends Vehicle {
	
	int cost = 4500;
	
	
	
	
	void start() {
		System.out.println("Car Started");
		
		
	}

}
