package HirarchialInheritance;

public class Bike extends Vehicle {
	
	String Fuel = "petrol";
	void stop() {
		System.out.println("Bike Stopped");
	}
	
	
	

}
