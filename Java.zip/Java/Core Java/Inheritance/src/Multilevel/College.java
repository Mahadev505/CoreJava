package Multilevel;

public class College extends University {
	
	String CollegeName = "Jspiders";
	void provideplacemebts(){
		
		System.out.println("Provides facilities");
		
	}
	

}
