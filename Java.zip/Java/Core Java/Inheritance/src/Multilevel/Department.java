package Multilevel;

public class Department extends College {
	
String department = "ComputerScience";

 void fest()
{
	 System.out.println("Computer Science Departmenr Had A Fest ");
	}

}
