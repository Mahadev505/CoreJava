package Multilevel;

public class University {
	
	String university = "vtu";
	
	
	void conductexams()
	{
		System.out.println("Vtu conducting exams");
		
	}
}
