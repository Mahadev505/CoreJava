package Multilevel;

public class Student {
	public static void main(String[] args) {
		
		Department d = new Department();
		
		
		System.out.println("university name"+d.university);
		System.out.println("Collegename"+d.CollegeName);
		System.out.println("Department name "+d.department);
		
		
		d.conductexams();
		d.fest();
		d.provideplacemebts();
	}

}
