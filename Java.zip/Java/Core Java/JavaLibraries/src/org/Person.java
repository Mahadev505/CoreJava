package org;

public class Person {
	public static void main(String[] args) {
		Person p = new Person();
		
		System.out.println(p);
	}

}
