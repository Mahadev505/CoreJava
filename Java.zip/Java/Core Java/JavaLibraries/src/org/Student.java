package org;

public class Student {
	String name;
	Student(String name){
		this.name = name;
		
		
	}
	@Override
	public String toString() {
		return this.name;
		
	}
	public static void main(String[] args) {
	Student s1 = new Student("Mahadev");
	Student s2 = new Student("Jerry");
	System.out.println(s1);
	System.out.println(s2);
	
	}
	

}
