package com;

public class Person {
	
	public static void main(String[] args) {
		Person p = new Person();
		p.toString();
		System.out.println(p.toString());
	}

}
