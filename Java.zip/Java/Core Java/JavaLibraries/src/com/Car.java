package com;

public class Car {
	public static void main(String[] args) {
		Object obj = new Car();
		
		Car c = new Car();
		c.toString();
		System.out.println("Hii");
	}

}
