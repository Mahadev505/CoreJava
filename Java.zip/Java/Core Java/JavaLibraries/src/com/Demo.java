package com;

import java.util.ArrayList;
import java.util.Scanner;

public class Demo 
{
	Scanner s = new Scanner(System.in);
	
	Thread t = new Thread();
	ArrayList l = new ArrayList();
	
	Object o = new Object();
	
	

}
